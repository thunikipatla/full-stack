import React, { Component } from 'react';
import BooksList from '../containers/BooksList';
import BooksPurchase from '../containers/BooksPurchase';
import ActiveBook from '../containers/ActiveBook';

export default class App extends Component {
  render() {
    return (
      <div>
        
        <BooksList/>
        {/* <BooksPurchase/> */}
        <ActiveBook/>

      </div>
    );
  }
}
