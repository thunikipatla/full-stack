export default function(state=null, action){

    console.log('action',action);
    switch(action.type){
        case 'SPECIFIC-BOOK': 
          return action.payload;
    }
    return state;
    
    }

