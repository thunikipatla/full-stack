export default function(){

    return [
        {
            name: "Book 1", price:200, author:"Author1"
        },
        {
            name: "Book 2", price:400, author:"Author2"
        },
        {
            name: "Book 3", price:900, author:"Author3"
        },
        {
            name: "Book 4", price:1200, author:"Author4"
        },
        {
            name: "Book 5", price:300, author:"Author5"
        },
        {
            name: "Book 6", price:500, author:"Author6"
        },
        {
            name: "Book 7", price:500, author:"Author7"
        }
    ]

}


/*

   {books: [ list of books]}


*/