export default function(){
    return [
        {
            name: "Book 1", price:200, author:"Author1", customer:"Ravi Kumar"
        },
        {
            name: "Book 2", price:400, author:"Author2", customer:"Kiran Kumar"
        },
        {
            name: "Book 3", price:900, author:"Author3",customer:"Krish Kumar"
        },
        {
            name: "Book 4", price:1200, author:"Author4",customer:"Sumeet Kumar"
        },
        {
            name: "Book 5", price:300, author:"Author5", customer:"Rajesh Kumar"
        },
        {
            name: "Book 6", price:500, author:"Author6",customer:"Anil Kumar"
        },
        {
            name: "Book 7", price:500, author:"Author7",customer:"Ajay Kumar"
        }
    ]

}
