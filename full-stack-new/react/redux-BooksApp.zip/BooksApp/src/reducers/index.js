import { combineReducers } from 'redux';
import BooksReducer from './reducer-books';
import PurchaseReducer from './reducer-purchaselist';
import ActiveBookReducer from './reducer-activebook';

const rootReducer = combineReducers({
  books: BooksReducer,
  purchases: PurchaseReducer,
  activeBook: ActiveBookReducer
});

export default rootReducer;
