export function selectBook(book){
    console.log('selected book', book);
    return {
        type: 'SPECIFIC-BOOK',
         payload: book
    }
}