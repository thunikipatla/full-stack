import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {selectBook} from '../actions/index';

class BooksList extends React.Component{

    renderBooks(){
         let listItems=this.props.books.map( (book) => {
            return <li
            onClick={() => {this.props.selectBook(book)}}
             key={book.name}
             >
             {book.name} {book.author}
             </li>
         })
         return listItems;
    }

    render(){

        console.log('props',this.props);
        return(
            <div>

               <h1>Books List</h1>

              Books, {this.props.books.length}

               <ul>
                   {this.renderBooks()}
                  
               </ul>

            </div>
        )
    }
}

function mapStateToProps(state){
    console.log('application state',state.books);

    let allBooks= {books: state.books}
return allBooks;
}

function bindActionToProps(dispatch){

    return bindActionCreators({selectBook:selectBook},dispatch)

}

export default connect(mapStateToProps,bindActionToProps)(BooksList);

