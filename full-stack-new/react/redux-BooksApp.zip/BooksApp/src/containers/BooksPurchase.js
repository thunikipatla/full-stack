import React from 'react';
import {connect} from 'react-redux';

class BooksPurchase extends React.Component{

    renderPurchases(){
        let listItems=this.props.purchases.map( (purchase) => {
           return <li key={purchase.name}>{purchase.price} {purchase.author} {purchase.customer}</li>
        })
        return listItems;
   }

   render(){
       return(
           <div>

              <h1>Purchases List</h1>

           

              <ul>
                  {this.renderPurchases()}
                 
              </ul>

           </div>
       )
   }
}

function mapStateToProps(state){
    return {
        purchases:state.purchases
    }
}

export default connect(mapStateToProps)(BooksPurchase);

