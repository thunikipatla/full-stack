import React from 'react';
import axios from 'axios';

class Login extends React.Component{

    constructor(){
        super();
        this.state= {
        emailId: "",
        password: "",
        }
        this.onInputChange = this.onInputChange.bind(this);
        this.formSubmit= this.formSubmit.bind(this);
        this.baseURL= "http://localhost:3019/api/";
     }
     onInputChange(event){
        var value=event.target.value;
        var name=event.target.name;
         this.setState({[name]:value})
     }
      formSubmit(event){
          event.preventDefault();
          console.log(this.state);
          axios.post(`${this.baseURL}login`,this.state).then(
              response => {
                  console.log(response);
              }
          )
      }
    render()
    {
        return(
            <div>

                <br></br>
                <br></br>

          <form onSubmit={this.formSubmit}>

          
          emailId: <input onChange={this.onInputChange}  type="text" name="emailId"></input> <br></br><br></br>
          password: <input onChange={this.onInputChange}   type="password" name="password"></input> <br></br><br></br>
          
          <button>Login</button>

          </form>

            </div>
        )
    }
}
export default Login;