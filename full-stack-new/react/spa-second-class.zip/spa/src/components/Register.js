import React from 'react';
import axios from 'axios';


class Register extends React.Component{

     constructor(){
        super();
        this.state= {
            firstName: "",
        lastName: "",
        emailId: "",
        password: "",
        mobileNumber: ""
        }
        this.onInputChange = this.onInputChange.bind(this);
        this.formSubmit= this.formSubmit.bind(this);
        this.baseURL= "http://localhost:3019/api/";
     }
     onInputChange(event){
        var value=event.target.value;
        var name=event.target.name;
         this.setState({[name]:value})
     }
      formSubmit(event){
          event.preventDefault();
          console.log(this.state);
          axios.post(`${this.baseURL}register`,this.state).then(
              response => {
                  console.log(response);
              }
          )
      }
    render()
    {
        return(
            <div>

                <br></br>
                <br></br>

          <form onSubmit={this.formSubmit}>

          firstName: <input onChange={this.onInputChange}   type="text" name="firstName"></input> <br></br><br></br>
          lastName: <input onChange={this.onInputChange}  type="text" name="lastName"></input> <br></br><br></br>
          emailId: <input onChange={this.onInputChange}  type="text" name="emailId"></input> <br></br><br></br>
          password: <input onChange={this.onInputChange}   type="password" name="password"></input> <br></br><br></br>
          mobileNumber: <input onChange={this.onInputChange}  type="text" name="mobileNumber"></input> <br></br><br></br>
          
          <button>Register</button>


          </form>

            </div>
        )
    }
    
}
export default Register;

/*

        firstName: firstName,
        lastName: lastName,
        emailId: emailId,
        password: password,
        mobileNumber: mobileNumber
*/