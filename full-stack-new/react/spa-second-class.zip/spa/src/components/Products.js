import React from 'react';


class Products extends React.Component{

    render()
    {
        return(
            <div>

                <br></br>
                <br></br>

         <h1>This is products component</h1>

            </div>
        )
    }
    
}
export default Products;