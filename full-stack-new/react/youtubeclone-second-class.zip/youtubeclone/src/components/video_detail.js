import React from 'react';

// stateless component
const VideoDetail= (props) => {

     // var obj=Object.assign({},props.video);

      var obj={...props.video};

    var x=Object.assign({},obj.id);
    console.log(x.videoId);

   var videoSrc=`https://www.youtube.com/embed/${x.videoId}`

    return(
         
         <iframe width="560" height="315" src={videoSrc} frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
       
    )

}
export default VideoDetail;


