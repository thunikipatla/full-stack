import React from 'react';
import logo from './logo.svg';
import './App.css';
import YTSearch from 'youtube-api-search';
import VideoList from './components/video_list';
import VideoDetail from './components/video_detail';

const API_KEY="AIzaSyCwh0vzM3kLBqGKQ84-dNBeYmwJk6_n6W8";


class App extends React.Component{
  constructor(){
    super();
    this.state= {
      videos:[],
      selectedVideo:null
    }
  }
   componentDidMount(){
     console.log("component did mount called!");

YTSearch({'key':API_KEY,term:'ipl'}, (videos) =>{
     this.setState({videos:videos,selectedVideo:videos[0]})
})
}
  render()
  {
    return(
      <div className="App">
      <h1>React Youtube App</h1>
       {this.state.videos.length}
       <VideoList onVideoSelected= {selectedVideo => this.setState({selectedVideo:selectedVideo})}
        videos={this.state.videos}/>
       <VideoDetail video={this.state.selectedVideo} />
</div>
    )
  }
}

// function App() {
//   return (
//     <div className="App">
//           <h1>React Youtube App</h1>
//     </div>
//   );
// }

export default App;
