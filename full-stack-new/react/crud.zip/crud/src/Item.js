import React from 'react';
import axios from 'axios';

class Item extends React.Component{
     
     constructor(){
         super();

          this.state={
              
                "itemId":null,
                "name":  null,
               "description": null,
                "assignedTo":null,
            "allItems":[],

          }
          this.inputChanged= this.inputChanged.bind(this);
          this.addItem= this.addItem.bind(this);
          this.getItems= this.getItems.bind(this);
          this.renderItemList= this.renderItemList.bind(this);
     }

     renderItemList(){

         let itemList=this.state.allItems.map(item => {
             return <tr key={item.itemId}>
             <td>{item.itemId}</td>
             <td>{item.name}</td>
             <td>{item.description}</td>
               </tr>;
         })
         return itemList;
     }

     inputChanged(event){
        let name= event.target.name; // let name="username"
        let value=event.target.value;
        this.setState({
             [name]: value 
        })
    }

    getItems(event){
        event.preventDefault();
        console.log(this.state);
         axios.get('http://localhost:9011/getItems').then(
             (response) =>{
               this.setState({allItems: response.data})
              
             }
             
         )
    }

    addItem(event){
         event.preventDefault();
          console.log(this.state);
          let item= {
            "itemId":this.state.itemId,
            "name":  this.state.name,
           "description": this.state.description,
            "assignedTo":this.state.assignedTo
      }
          axios.post('http://localhost:9011/addItem',item).then(
              (response) =>{
                   
                   if(response.data){
                     this.setState({message: 'Item added successfully'})
                     this.getItems(event);
                   }
              }
         )
          
     }
     render(){

        return(
             <div>
                  
                  <form>
            itemId: <input type="text" onChange={this.inputChanged} name="itemId"/><br></br><br></br>
            name: <input type="text" onChange={this.inputChanged} name="name"/><br></br><br></br>
            description: <input type="text" onChange={this.inputChanged} name="description"/><br></br><br></br>
            assignedTo: <input type="text" onChange={this.inputChanged} name="assignedTo"/><br></br><br></br>
                     <button onClick={this.addItem}>Add Item</button>
                     <button onClick={this.getItems}>Show Items</button>
                 </form>  

                 <h1>{this.state.message}</h1>
                 <h1>{this.state.allItems.length}</h1>

                  <table border="1" width="100%" height="50%">
                      <tbody>
                      {this.renderItemList()}
                      </tbody>
                     
                  </table>

             </div>
        )
     }

}

export default Item;