import React from 'react';
import logo from './logo.svg';
import './App.css';
import Item from './Item';

function App() {
  return (
    <div className="App">
      <Item/>
    </div>
  );
}
export default App;
