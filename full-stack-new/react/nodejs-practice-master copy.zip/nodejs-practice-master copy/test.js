var str="hello how are you!";

var data=str.split("").reverse().join("");
console.log(data);
var res=data.split(" ").reverse().join(" ");
console.log(res);