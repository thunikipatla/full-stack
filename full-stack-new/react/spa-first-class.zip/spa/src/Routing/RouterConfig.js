import React from 'react';
import {Route} from 'react-router-dom';
import Login from '../components/Login';
import Register from '../components/Register';
import Products from '../components/Products';
class RouterConfig extends React.Component{
    render()
    {
        return(
            <div>
             
             <Route path="/login" component={Login}></Route>
             <Route path="/register" component={Register}></Route>
             <Route path="/products" component={Products}></Route>

            </div>
        )
    }
}
export default RouterConfig;