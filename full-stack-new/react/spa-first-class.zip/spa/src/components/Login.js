import React from 'react';


class Login extends React.Component{

    render()
    {
        return(
            <div>

                <br></br>
                <br></br>

          <form>

          Username: <input  type="text"></input>
          Password: <input  type="password"></input>
          <button>Login</button>


          </form>

            </div>
        )
    }
    
}
export default Login;