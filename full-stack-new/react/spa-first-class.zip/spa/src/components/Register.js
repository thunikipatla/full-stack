import React from 'react';


class Register extends React.Component{

    render()
    {
        return(
            <div>

                <br></br>
                <br></br>

          <form>

          Username: <input  type="text"></input>
          EmailId: <input  type="text"></input>
          Password: <input  type="password"></input>
          <button>Register</button>


          </form>

            </div>
        )
    }
    
}
export default Register;