import React from 'react';
import {NavLink} from 'react-router-dom';

class Header extends React.Component{

    render()
    {
        return(
            <div>

{/* 
    <div>
        <a href="">Login</a>
        <a href="">Register</a>
    </div> */}

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">

  <NavLink class="navbar-brand" to="/home">ECommerce</NavLink>
  <ul class="navbar-nav">
    <li class="nav-item">
      <NavLink class="nav-link" to="/login">Login</NavLink>
    </li>
    <li class="nav-item">
      <NavLink class="nav-link" to="/register">Register</NavLink>
    </li>
    <li class="nav-item">
      <NavLink class="nav-link" to="/products">Products</NavLink>
    </li>
  </ul>
</nav>
            </div>
        )
    }
    
}
export default Header;