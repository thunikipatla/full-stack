// apiURL: http://localhost:3000/customer/register
/*

method: POST

request body:
{
	"emailId": "saikumar@gmail.com",
    "password":  "saikumar",
   "mobileNumber": 9010101010
}
response :

token : 

*/

import React from 'react';
import axios from 'axios';

class Register extends React.Component{
       posts=[];
     constructor(){
         super();

          this.state={
            "emailId":null,
            "password":  null,
           "mobileNumber": null,
            "posts":[]
          }
          this.inputChanged= this.inputChanged.bind(this);
          this.register= this.register.bind(this);
          this.getPosts= this.getPosts.bind(this);
          //this.x= this.x.bind(this);
     }

     inputChanged(event){
        let name= event.target.name; // let name="username"
        let value=event.target.value;
        this.setState({
             [name]: value 
        })
    }

    getPosts(event){
       
        event.preventDefault();
        console.log(this.state);
         axios.get('https://jsonplaceholder.typicode.com/posts').then(
             function(response){
               //console.log(this.state);
             }
             
         )
    }

     register(event){
         event.preventDefault();
          console.log(this.state);
          axios.post('http://localhost:3000/customer/register',this.state).then(
              function(response){
                   console.log(response.data.token);
                   if(response.data.token){
                     alert("registered successfully!");
                   }
              }
          )
          
     }
     render(){

        return(
             <div>
                  
                  <form>
                     EmailId: <input type="text" onChange={this.inputChanged} name="emailId"/><br></br><br></br>
                     Password: <input type="password" onChange={this.inputChanged} name="password"/><br></br><br></br>
                     mobile Number: <input type="text" onChange={this.inputChanged} name="mobileNumber"/><br></br><br></br>
                     <button onClick={this.register}>Register</button>
                     <button onClick={this.getPosts}>Get Posts</button>
                 </form>  
               

             </div>
        )
     }

}

export default Register;