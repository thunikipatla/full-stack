import React from 'react';
import VideoListItem from './video_list_item';

class VideoList extends React.Component{

    renderList(){
        let videosList=this.props.videos.map( (video) => {
                return <VideoListItem video={video}></VideoListItem>
            //  return <li key={video.etag}>{video.snippet.title}</li>
        }
        )
        return videosList;
    }
    render(){

        console.log("I am in props",this.props);

        return(
            <div>
                 <h1>Video List</h1>

                   <ul>
                   {this.renderList()}
                   </ul>

                 

            </div>
        )
    }
}

export default VideoList;