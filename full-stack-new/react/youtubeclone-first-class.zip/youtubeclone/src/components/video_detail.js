import React from 'react';

// stateless component
const VideoDetail= (props) => {

    console.log(props);

    return(
         
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Ju1FdLLamnU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    )

}

export default VideoDetail;