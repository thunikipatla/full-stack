import React from 'react';

// stateless component
const VideoListItem= (props) => {

    console.log(props);

    return(
         
        <li>
            <h1> {props.video.snippet.title}  </h1>
            <img src={props.video.snippet.thumbnails.medium.url}></img>

        </li>
    )

}

export default VideoListItem;