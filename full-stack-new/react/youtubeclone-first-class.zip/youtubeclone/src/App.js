import React from 'react';
import logo from './logo.svg';
import './App.css';
import YTSearch from 'youtube-api-search';
import VideoList from './components/video_list';
import VideoDetail from './components/video_detail';

const API_KEY="AIzaSyAkYRBrYfVDvWpNTxAkmiF3MoZ3oXK8Sfw";


class App extends React.Component{
  constructor(){
    super();
    this.state= {
      videos:[]
    }
  }
   componentDidMount(){
     console.log("component did mount called!");

YTSearch({'key':API_KEY,term:'cricket'}, (videos) =>{
     this.setState({videos:videos})
})
}
  render()
  {
    return(
      <div className="App">
      <h1>React Youtube App</h1>
       {this.state.videos.length}
       <VideoList videos={this.state.videos}/>
       <VideoDetail/>
</div>
    )
  }
}

// function App() {
//   return (
//     <div className="App">
//           <h1>React Youtube App</h1>
//     </div>
//   );
// }

export default App;
